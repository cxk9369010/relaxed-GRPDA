function [ dis] = dist_sub(la,x,y)
a = [y(x>0)-la; y(x<0)+la];
b = y(x==0);

c1 = b(b<-la) + la; 
c2 = b(b>la)-la;
dis = norm([a;c1;c2],1);

end

