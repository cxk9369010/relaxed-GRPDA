% basis pursuit problem
%
%       min_x ||x||_1 , s.t.  K*x = b.
%
% Created by Xiaokai  Chang.
% Email: xkchang@lut.edu.cn.
% Date: 08/10/2022.
clear all

file_path1 = 'E:\���ܵ�����\JSC\2022\note_for_special_cases\code\GRPDA_bp\solvers';
file_path2 = 'E:\���ܵ�����\JSC\2022\note_for_special_cases\code\GRPDA_bp\utilities';

addpath(file_path1)
addpath(file_path2)
%% Generate the input data.
scale  = 8; % Change this to get different problem size
p      = scale*1024;
%m      = scale*320;   s  = scale*100;

 m = floor(p/6); s = floor(m/6);
fprintf('\nSize [p,m,s] = [%i,%i,%i]\n',p,m,s);
seed =1;
rand('seed', seed);
randn('seed', seed);

% Generate x_org.
x_org    = zeros(p, 1);
T        = randperm(p, s);
x_org(T) = unifrnd(-10,10,s, 1);


% Generate K by all two kinds
pp = randperm(p);
picks = sort(pp(1:m)); picks(1) = 1;
perm = randperm(p);
Mtype = {' pdct','pdwht'};
op_K = eval(['@' Mtype{1} '_operator']);
K = feval(op_K,picks,perm);
LAMBDA = 1;	% regularizor
if p<5000
    hh = eye(p,p);
    K_m = zeros(m,p);
    for i = 1:p
        K_m(:,i) = K.times(hh(:,i));
    end
end

% Generate vector b.
b        = K.times(x_org);
b_norm   = norm(b);
% 
if p<5000
 cvx_begin
     variable x(p);
     minimize( LAMBDA*norm(x,1) );
     subject to
     K_m*x == b;
          
 cvx_end
 fx_cvx    = LAMBDA*norm(x,1);
end

%% Operators.
soft_threshold    = @(x, coef) sign(x).*max(abs(x) - coef, 0);
FxFunc.gyFunc     = @(y)       LAMBDA*norm(y, 1);
FxFunc.gsProx     = @(y, coef) soft_threshold(y, LAMBDA*coef);

FxFunc.fxProx     = @(x, coef) x - coef*b;
FxFunc.fwProx     = @(x, coef) b;
FxFunc.K_oper     = @(x)       -K.trans(x);
FxFunc.KT_oper    = @(y)       -K.times(y);
FxFunc.FxwFull     = @(x, w)   LAMBDA*norm(x,1);
FxFunc.FxFull     = @(x, y)    0;
FxFunc.GyFull     = @(x, y)    LAMBDA*norm(x,1);

%% Initializations
% Initial points.
x0 = zeros(m, 1);
y0 = zeros(p, 1);

% Initialize parameters
options.MaxIters     = 1e+5;
options.printStep    = 2000;
options.verbosity    = 1;
options.isSaveHist   = 1;
options.isRestart    = 0;
options.nRestart     = 50;

% Define the parameters for runs.
normK                = 1;
param.K_nrm2         = normK^2;
GAMMA_CP             = 0.9;


%% Run all the algorithms.

%% Chambole-Pock's method  ...
fprintf('\nRunning Chambolle-Pock method ...\n');
options.isAvgEval = 0;
param.gamma = GAMMA_CP;
param.rho0  = sqrt(2)/normK;
param.la = LAMBDA;
param.theta = 1;
[xoptCp, outputCp] = CpAlg_w(FxFunc, x0, y0, param, options);

%% GRPDA method ...
fprintf('\nRunning GR-PDA method...\n');
options.isAvgEval = 0;
param.psi = 1.6;
param.la = LAMBDA;
param.c = b;
psi  = param.psi;
beta = sqrt(8);
theta = sqrt(psi*(2*psi+2-psi^2)/(1+psi));
param.rho0  = beta * theta / normK;
[xoptGRPDA0, outputGRPDA0] = GRPDA_Alg_w(FxFunc, x0, y0, param, options);



param.psi = 1.8;
theta = sqrt(psi*(2*psi+2-psi^2)/(1+psi));
param.rho0  = beta * theta / normK;
[xoptGRPDA1, outputGRPDA1] = GRPDA_Alg_w(FxFunc, x0, y0, param, options);


beta = 1;
theta = sqrt(psi*(2*psi+2-psi^2)/(1+psi));
param.rho0  = beta * theta / normK;
[xoptGRPDA2, outputGRPDA2] = GRPDA_Alg_updating(FxFunc, x0, y0, param, options);



%% Plotting ...
% Last iterates
 objVals = [outputGRPDA0.fvalue; outputGRPDA1.fvalue; outputGRPDA2.fvalue];

if p<5000
    fx_cvx1  = fx_cvx;
else
    fx_cvx1  = min(outputGRPDA1.fvalue(end-10,end));
end
    

figure(1);
h1 = subplot(1,1,1);
%semilogy(abs(outputCp.fvalue-fx_cvx1)/fx_cvx1, 'k', 'LineWidth', 2); hold on;
semilogy(abs(outputGRPDA0.fvalue-fx_cvx1)/fx_cvx1, 'm', 'LineWidth', 2); hold on;
semilogy(abs(outputGRPDA1.fvalue-fx_cvx1)/fx_cvx1, 'b-.', 'LineWidth',2); hold on;
semilogy(abs(outputGRPDA2.fvalue-fx_cvx1)/fx_cvx1, 'r--', 'LineWidth', 2); hold on;

str_legend1 = {'$\psi=1.6$','$\psi=1.8$','$\psi=1.8$, adaptive $\beta$'};
legend(h1, str_legend1, 'Interpreter', 'Latex', 'FontSize', 14);
xlabel('Iterations', 'Interpreter', 'Latex', 'FontSize', 14);
ylabel('$\frac{|\Phi(x_n,w_n) - \Phi^*|}{\Phi^*}$', 'Interpreter', 'Latex', 'FontSize', 16);
set(gca,'FontSize',14,'LineWidth',1);



figure(2);
h1 = subplot(1,1,1);
%semilogy(outputCp.infeas, 'k', 'LineWidth', 2); hold on;
semilogy(outputGRPDA0.infeas, 'm', 'LineWidth', 2); hold on;
semilogy(outputGRPDA1.infeas, 'b-.', 'LineWidth', 2); hold on;
semilogy(outputGRPDA2.infeas, 'r--', 'LineWidth', 2); hold on;


str_legend1 = {'$\psi=1.6$','$\psi=1.8$','$\psi=1.8$, adaptive $\beta$'};
legend(h1, str_legend1, 'Interpreter', 'Latex', 'FontSize', 14);
xlabel('Iterations', 'Interpreter', 'Latex', 'FontSize', 14);
ylabel('$\frac{\|Kx_n-b\|_1}{1+\|b\|_1}$', 'Interpreter', 'Latex', 'FontSize', 16);
set(gca,'FontSize',14,'LineWidth',1);



%% End ...