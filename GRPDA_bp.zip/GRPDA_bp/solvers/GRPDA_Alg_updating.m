% This function implements the GRPDA with adaptive beta to solve:
%                   min_x f(x) + g(K(x))
% where f and g are convex, and K is a given linear operator.
% 
% Created by Xiaokai  Chang.
% Email: xkchang@lut.edu.cn.
% Date: 08/10/2022.
%
function [xopt, output] = GRPDA_Alg_updating(fxFunc, x0, y0, param, options)

% Define operators
K_oper  = fxFunc.K_oper;
KT_oper = fxFunc.KT_oper;
% fwProx  = fxFunc.fwProx;
gsProx  = fxFunc.gsProx;
FxwFull  = fxFunc.FxwFull;
% GyFull  = fxFunc.GyFull;


% Initialize parameters
K_nrm2    = param.K_nrm2;
tau0      = param.rho0;
psi     = param.psi;
sigma0     = psi/(K_nrm2*tau0);
la = param.la; 
c = param.c; 
norm_c = norm(c,1);

MUmin = 1e-6;
MUmax = 1e+6;



% Initialize variables
x_cur   = x0;
z_cur = y0;
Kx_cur  = K_oper(x_cur);
y_cur   = y0;
KTy_cur = KT_oper(y_cur);

% Save the history.
output      = [];

fprintf('The Golden-Ratio PDA method with adaptive beta ...\n');
time1 = tic;
it_pinf = 0;
it_dinf = 0;
% The main loop.
for iter = 1:options.MaxIters

    % The dual step.
    z_next  = (psi-1)/psi*y_cur + 1/psi*z_cur;
    y_next = gsProx(z_next + tau0*Kx_cur, tau0);
    
    % Primal step.
    KTy_next = KT_oper(y_next);
    w_next = c;
    x_next   = x_cur + sigma0*(-KTy_next - w_next);
    
    
     % Evaluate the objective values.
    fx_val = FxwFull(y_next, w_next);
    infeas_val = norm(-KTy_next - w_next,1)/(1+norm_c);
    
    Kx_next  = K_oper(x_next);
    
     pinf = infeas_val;
     dinf = dist_sub(la,y_next, Kx_next)/(1+norm(y_next,1));
     inf = max(pinf,dinf);
     

    
dtmp=pinf/dinf;  
 if iter<=21;       h4=3;
 elseif iter<=61;   h4=6;    
 elseif iter<=121;  h4=50;
 elseif iter<=1001;  h4=100;
 else
     h4=500;
 end
 
 if inf > 1e-3
     kk = 0.8;
 else
     kk = 0.9;
 end
   
 if dtmp<=0.8
    it_pinf = it_pinf+1;
    it_dinf = 0;
    if it_pinf>h4
       tau0 = min(1/kk*tau0,MUmax); sigma0 = max(kk*sigma0,MUmin); 
       it_pinf=0;
    end
  else if dtmp>=1.25
          it_dinf = it_dinf+1; 
          it_pinf = 0;
          if it_dinf>h4
             tau0 = max(kk*tau0,MUmin); sigma0 = min(1/kk*sigma0,MUmax);             
             it_dinf = 0;
          end
       end
 end
    
    % Update for the next iteration.
    z_cur   = z_next;
    x_cur   = x_next;
    Kx_cur  = Kx_next;
    y_cur   = y_next;

    
    % Save the history.
    
        output.time(iter,1) = toc(time1);
        output.fvalue(iter, :)   = fx_val;
        output.infeas(iter, :)   = infeas_val;
   
    % Print the iteration.
    if mod(iter, options.printStep) == 0 || iter == 1 || inf < 5e-6
        fprintf('iter = %4d, F(x,w) = %5.6e, p_inf = %3.2e, d_inf = %3.2e\n',... 
                iter, fx_val, pinf, dinf);
    end
    if inf < 5e-6
         break;
     end
end

% Finalization.
xopt = x_cur;
output.yopt = y_cur;
end
