from __future__ import division
import numpy as np
import scipy as sp
import numpy.linalg as LA
from itertools import count
from time import time


### Proximal Gradient Methods ###

def prox_grad(J,  d_f, prox_g, x0, la, numb_iter=100):
    """
    Minimize function F(x) = f(x) + g(x) by proximal gradient method
    with fixed stepsize la.  Takes J as some evaluation function for
    comparison.
    """
    begin = time()
    values = [J(x0)]
    tt = [0]
    x = x0
    for i in range(numb_iter):
        x = prox_g(x - la * d_f(x), la)
        values.append(J(x))
        tt.append(time() - begin)

    end = time()
    print ("---- PGM ----")
    print ("Time execution:", round(end - begin,2))
    return values, x, tt



### =============================================================== ###


### Accelerated Methods ###

def fista(J, d_f, prox_g, x0, la, numb_iter=100):
    """
    Minimize function F(x) = f(x) + g(x) using FISTA.  
    Takes J as some evaluation function for comparison.
    """
    begin = time()
    values = [J(x0)]
    tt = [0]
    res = [values, x0, x0, 1,tt]

    def iter_T(values, x, y, t,tt):
        x1 = prox_g(y - la * d_f(y), la)
        t1 = 0.5 * (1 + np.sqrt(1 + 4 * t**2))
        y1 = x1 + (t - 1) / t1 * (x1 - x)
        values.append(J(x1))
        tt.append(time() - begin)
        return [values, x1, y1, t1,tt]

    for i in range(numb_iter):
        res = iter_T(*res)

    end = time()
    print ("---- FISTA----")
    print ("Time execution:", round(end - begin,2))
    return res



### =============================================================== ###

def tseng_fbf(J, F, prox_g, x0, la, numb_iter=100):
    """
    Solve monotone inclusion $0 \in F + \partial g by Tseng
    forward-backward-forward method with a fixed step. In particular,
    minimize function F(x) = f(x) + g(x) with convex smooth f and
    convex g. Takes J as some evaluation function for comparison.
    """
    res = [[J(x0)], x0]
    tt = [0]

    def iter_T(values, x,tt):
        Fx = F(x)
        z = prox_g(x - la * Fx, la)
        x = z - la * (F(z) - Fx)
        values.append(J(x))
        tt.append(time() - begin)
        return [values, x,tt]

    for i in range(numb_iter):
        res = iter_T(*res)
    return res

### =============================================================== ###
# SpaRSA #


def sparsa(J, f, d_f, prox_g, x0, la=1, numb_iter=100, time_bound=3000):
    """
    Minimize function F(x) = f(x) + g(x) using SpaRSA.
    J = f + g
    In the paper stepsize a was like Lipschitz constant, hence la = 1/a
    """
    begin = time()
    mu = 0.7
    a_min = 1e-30
    a_max = 1e30
    sigma = 0.01
    M = 5
    # make one iteration of the proximal gradient with standard linesearch
    x = x0
    for j in count(0):
        dfx = d_f(x)
        fx = f(x)
        x1 = prox_g(x - la * dfx, la)
        fx1 = f(x1)
        if fx1 <= fx + np.vdot(dfx, x1 - x) + 0.5 / la * LA.norm(x1 - x)**2:
            break
        else:
            la *= mu

    Jx1 = J(x1)
    values = [Jx1]
    time_list = [time() - begin]
    iterates = [time_list, values, x1, x, dfx]

    def iter_T(time_list, values, x, x_old, dfx_old):
        dfx = d_f(x)
        s = x - x_old
        r = dfx - dfx_old
        s_norm2 = np.dot(s, s)
        a = np.dot(s, r) / s_norm2 if s_norm2 > a_min else a_min
        # print(s.dot(s), a)
        a = np.clip(a, a_min, a_max)
        la = 1. / a
        # print(LA.norm(s), la)
        J_max = max(values[-M:])
        for j in count(0):
            x1 = prox_g(x - la * dfx, la)
            Jx1 = J(x1)
            if Jx1 <= J_max - sigma / (2 * la) * LA.norm(x1 - x)**2:
                break
            else:
                la *= mu
        ans = [time_list, values, x1, x, dfx]
        values.append(Jx1)
        time_list.append(time() - begin)
        return ans

    for i in range(numb_iter):
        if iterates[0][-1] <= time_bound:
            iterates = iter_T(*iterates)
        else:
            break

    end = time()
    return [iterates[i] for i in [1]]
##### Algorithms from paper PEGM ########################


def initial_lambda(F, x0, a, prec=1e-10):
    """
    Finds initial stepsize.

    With given map F and starting point x0 compute la_0 as an
    approximation of local Lipschitz constant of F in x0. This helps to
    make a better choice for the initial stepsize.  The resulting
    output is the full iterate information for the algorithm.

    """
    gen = 100  # random generator
    np.random.seed(gen)
    x1 = x0 + np.random.random(x0.shape) * prec
    Fx0 = F(x0)
    # need to fix division in case of zero in the denominator
    la0 = a * np.sqrt(np.vdot(x1 - x0, x1 - x0) /
                      np.vdot(F(x1) - F(x0), F(x1) - F(x0)))
    res = [x1, x0, x0, la0, Fx0]
    return res
