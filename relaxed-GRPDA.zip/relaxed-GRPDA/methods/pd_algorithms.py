from __future__ import division
import numpy as np
import numpy.linalg as LA
from itertools import count
from time import time


def pd(J, prox_g, prox_f_conj, K,  x0, y0, sigma, tau, numb_iter=100):
    """
    Primal-dual algorithm of Pock and Chambolle for the problem min_x
    max_y [<Kx,y> + g(x) - f*(y)] 
    J denotes some function which we compute in every iteration to
    study perfomance. It may be energy, primal-dual gap, etc.
    """
    begin = time()
    theta = 1.0
    x, y, z = x0, y0, x0
    values = [J(x0, y0)]
    tt = [0]
    
    for i in range(numb_iter):
        x1 = prox_g(x - tau * K.T.dot(y), tau)
        z = x1 + theta * (x1 - x)
        #z = x1 - tau * K.T.dot(y)
        #z = x1
        y = prox_f_conj(y + sigma * K.dot(z), sigma)
        x = x1
        values.append(J(x, y))
        tt.append(time() - begin)
        
    end = time()
    print ("----- Primal-dual method -----")
    print ("Time execution:", round(end - begin,2))
    return [values, x, y,tt]

def pd_accelerated_primal(J, prox_g, prox_f_conj, K,  x0, y0, sigma, tau, gamma, numb_iter=100):
    """
    Accelerated primal-dual algorithm of Pock and Chambolle for problem
    min_x max_y [<Kx,y>  + g(x) - f*(y)], where g is gamma-strongly convex
    """
    begin = time()
    theta = 1.0
    x, y, z = x0, y0, x0
    values = [J(x0, y0)]
    tt = [0]
    for i in range(numb_iter):
        y = prox_f_conj(y + sigma * K.dot(z), sigma)
        x1 = prox_g(x - tau * K.T.dot(y), tau)
        theta = 1. / np.sqrt(1 + gamma * tau)
        tau *= theta
        sigma *= 1. / theta
        z = x1 + theta * (x1 - x)
        x = x1
        values.append(J(x, y))
        tt.append(time() - begin)
    end = time()
    print ("----- Accelerated primal-dual method (g(x) is strongly convex)-----")
    print ("Time execution:",  round(end - begin,2))
    return [values, x, y,tt]

