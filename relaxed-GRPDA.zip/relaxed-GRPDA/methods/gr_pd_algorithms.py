from __future__ import division
import numpy as np
import numpy.linalg as LA
from itertools import count
from time import time
from scipy import linalg as scp_LA

def pd_Golden_y(J, prox_g, prox_f,dis_sub,  K,  x0, y0, sigma, tau, phi,la,b, numb_iter=100):
    """
    Golden-Ratio Primal-dual algorithm for the problem 
    min_x max_y [<Kx,y> + g(x) - f*(y)] 
    J denotes some function which we compute in every iteration to
    study perfomance. It may be energy, primal-dual gap, etc.
    """
    begin = time()
    x, y, z = x0, y0, y0
    values = [J(x0, y0)]
    infeas = []
    tt = [0]
    KTy = K.T.dot(y)
    
    for i in range(numb_iter):
        x = prox_g(x - tau * KTy, tau)
        z= y-(1/phi)*(y - z)  ##  convex combination for y-subproblem
        #y = prox_f_conj(z + sigma * K.dot(x), sigma)
        Kx = K.dot(x)
        w = prox_f(z/sigma +  Kx, 1/sigma)
        p_inf = LA.norm(Kx - w,1)
        y = z + sigma * (Kx-w)
        KTy = K.T.dot(y)
        
        values.append(J(x, w))
        infeas.append(p_inf)
        tt.append(time() - begin)
        
        p_inf = LA.norm(Kx - w,1)
        d_inf = LA.norm(w - y -b,1)/(1+LA.norm(b,1)) + dis_sub(la,x,KTy)
        if p_inf <= 1e-7 and d_inf <= 1e-7:
            end = time()
            print ("----- Golden-Ratio PDA with y convex combination -----")
            print ("Time execution:", round(end - begin,2))
            return [values,infeas, x, y,tt]
        
    end = time()
    print ("----- Golden-Ratio PDA with y convex combination -----")
    print ("Time execution:", round(end - begin,2))
    return [values,infeas, x, y,tt]


def pd_Golden(J, prox_g, prox_f, dis_sub, K,  x0, y0, sigma, tau, phi,la,b, numb_iter=100):
    """
    Golden-Ratio Primal-dual algorithm for the problem 
    min_x max_y [<Kx,y> + g(x) - f*(y)] 
    J denotes some function which we compute in every iteration to
    study perfomance. It may be energy, primal-dual gap, etc.
    """
    begin = time()
    
    x, y, z = x0, y0, x0
    values = [J(x0, y0)]
    infeas = []
    tt = [0]
    KTy = K.T.dot(y)
    
    for i in range(numb_iter):
        z = x-(1/phi)*(x - z)
        x = prox_g(z - tau * KTy, tau)
        #y = prox_f_conj(y + sigma * K.dot(x), sigma)
        Kx = K.dot(x)
        w = prox_f(y/sigma +  Kx, 1/sigma)
        p_inf = LA.norm(Kx - w,1)
        y = y + sigma * (Kx - w)
        KTy = K.T.dot(y)
        
        values.append(J(x, w))
        infeas.append(p_inf)
        tt.append(time() - begin)
        p_inf = LA.norm(Kx - w,1)
        d_inf = LA.norm(w - y -b,1)/(1+LA.norm(b,1)) + dis_sub(la,x,KTy)
        if p_inf <= 1e-7 and d_inf <= 1e-7:
            end = time()
            print ("----- Golden-Ratio PDA  -----")
            print ("Time execution:", round(end - begin,2))
            return [values,infeas, x, y,tt]
        
    end = time()
    print ("----- Golden-Ratio PDA-----")
    print ("Time execution:", round(end - begin,2))
    return [values,infeas, x, y,tt]
def pd_Golden_adaptive_beta(J, prox_g, prox_f, dis_sub, K, x0, y0, sigma, tau, phi,la,b, numb_iter=100):
    """
    Golden-Ratio Primal-dual algorithm for the problem 
    min_x max_y [<Kx,y> + g(x) - f*(y)] 
    J denotes some function which we compute in every iteration to
    study perfomance. It may be energy, primal-dual gap, etc.
    """
    begin = time()
    it_pinf = 0
    it_dinf = 0
    MUmin = 1e-6
    MUmax = 1e+6
    eta = 0.8
    
    x, y, z = x0, y0, x0
    values = [J(x0, y0)]
    infeas = []
    tt = [0]
    Kx = K.dot(x)
    KTy = K.T.dot(y)
    
    for i in range(numb_iter):
        z = x-(1/phi)*(x - z)
        x = prox_g(z - tau * KTy, tau)
        Kx = K.dot(x)
        #y = prox_f_conj(y + sigma * Kx, sigma)
        w = prox_f(y/sigma + Kx, 1/sigma)
        y = y + sigma * (Kx - w)
        KTy = K.T.dot(y)
        
        p_inf = LA.norm(Kx - w,1)
        d_inf = dis_sub(la,x,KTy) ## LA.norm(w - y -b,1) == 0
        
        
        dtmp = p_inf/d_inf
        max_inf = np.max([p_inf, d_inf])
        ## updating beta：=sigma /tau adaptively
        if i <= 21:
             hh =3
        elif i <= 61:
            hh =6
        elif i <= 121:
            hh =50
        else:
            hh = 100
         
        if dtmp <= 0.8:
            it_pinf = it_pinf+1
            it_dinf = 0
            if it_pinf > hh:
                tau = min(1/eta*tau,MUmax)
                sigma = max(eta*sigma,MUmin)
                it_pinf=0
        elif dtmp >= 1.25:
            it_dinf = it_dinf+1; 
            it_pinf = 0;
            if it_dinf > hh:
                tau = max(eta*tau,MUmin)
                sigma = min(1/eta*sigma,MUmax) 
                it_dinf = 0;
 
        #print(sigma/tau)
        values.append(J(x, w))
        infeas.append(p_inf)
        tt.append(time() - begin)
        
        if max_inf <= 1e-7:
            end = time()
            print ("----- Golden-Ratio PDA with updating beta -----")
            print ("Time execution:", round(end - begin,2))
            return [values,infeas, x, y,tt]
            
   
        
    end = time()
    print ("----- Golden-Ratio PDA with updating beta-----")
    print ("Time execution:", round(end - begin,2))
    return [values,infeas, x, y,tt]


