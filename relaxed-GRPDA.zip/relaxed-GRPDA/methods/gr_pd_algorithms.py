from __future__ import division
import numpy as np
import numpy.linalg as LA
from itertools import count
from time import time
from scipy import linalg as scp_LA

def pd_Golden_y(J, prox_g, prox_f_conj, K,  x0, y0, sigma, tau, phi, numb_iter=100):
    """
    Golden-Ratio Primal-dual algorithm for the problem min_x
    max_y [<Kx,y> + g(x) - f*(y)] 
    J denotes some function which we compute in every iteration to
    study perfomance. It may be energy, primal-dual gap, etc.
    """
    begin = time()
    
    x, y, z = x0, y0, y0
    values = [J(x0, y0)]
    tt = [0]
    
    for i in range(numb_iter):
        #z = x-(1/phi)*(x - z)
        x = prox_g(x - tau * K.T.dot(y), tau)
        z= y-(1/phi)*(y - z)
        y = prox_f_conj(z + sigma * K.dot(x), sigma)
        
        values.append(J(x, y))
        tt.append(time() - begin)
        
    end = time()
    print ("----- Golden-Ratio PDA-----")
    print ("Time execution:", round(end - begin,2))
    return [values, x, y,tt]


def pd_Golden(J, prox_g, prox_f_conj, K,  x0, y0, sigma, tau, phi, numb_iter=100):
    """
    Golden-Ratio Primal-dual algorithm for the problem min_x
    max_y [<Kx,y> + g(x) - f*(y)] 
    J denotes some function which we compute in every iteration to
    study perfomance. It may be energy, primal-dual gap, etc.
    """
    begin = time()
    
    x, y, z = x0, y0, x0
    values = [J(x0, y0)]
    tt = [0]
    
    for i in range(numb_iter):
        z = x-(1/phi)*(x - z)
        x = prox_g(z - tau * K.T.dot(y), tau)
        
        y = prox_f_conj(y + sigma * K.dot(x), sigma)
        
        values.append(J(x, y))
        tt.append(time() - begin)
        
    end = time()
    print ("----- Golden-Ratio PDA-----")
    print ("Time execution:", round(end - begin,2))
    return [values, x, y,tt]

def pd_Golden_Balanced(J, prox_g, prox_f, K,  x0, y0, sigma, tau, phi, numb_iter=100):
    """
    Golden-Ratio Primal-dual algorithm for the problem min_x
    max_y [<Kx,y> + g(x) - f*(y)] 
    J denotes some function which we compute in every iteration to
    study perfomance. It may be energy, primal-dual gap, etc.
    """
    begin = time()
    M = tau/phi * K.dot(K.T)
    p,q = M.shape
    M = M + (1/sigma + 0.001)*np.eye(p,q)
    L = np.linalg.cholesky(M)
    
    x, y, z, w = x0, y0, x0, K.dot(x0)
    values = [J(x0, y0)]
    tt = [0]
    
    for i in range(numb_iter):
        z = x-(1/phi)*(x - z)
        x = prox_g(z - tau * K.T.dot(y), tau)
        w1 = prox_f(w +  y/sigma, 1/sigma)
        y_temp = scp_LA.solve_triangular(L, K.dot(x) - (2*w1-w), lower=True)
        y = y + scp_LA.solve_triangular(L.T, y_temp, lower=False)
        
        w = w1
        #y = prox_f_conj(y + sigma * K.dot(x), sigma)
        
        values.append(J(x, y))
        tt.append(time() - begin)
        
    end = time()
    print ("----- Golden-Ratio PDA-----")
    print ("Time execution:", round(end - begin,2))
    return [values, x, y,tt]

def GR_ADMM(J, prox_g, prox_f_conj, K,  x, y, sigma, tau,phi, numb_iter=100):
    """
    Golden-Ratio ADMM for the problem min_x
    max_y [<Kx,y> + g(x) - f*(y)] 
    J denotes some function which we compute in every iteration to
    study perfomance. It may be energy, primal-dual gap, etc.
    """
    begin = time()
    
    Kx = K.dot(x)
    Kx0 = Kx
    KTy = K.T.dot(y)
    Kz = Kx
    
    z = x
    KTy1 = KTy
    values = [J(x, y)]
    tt = [0]
    
    for i in range(numb_iter):
        y1 = prox_f_conj(y + sigma * Kx, sigma)
        
        z = ((phi-1)*x + z)/phi
        Kz = ((phi-1)*Kx + Kz)/phi
        
        x = prox_g(z - tau * K.T.dot(2*y1 - y - sigma*(Kz - Kx)), tau)
        Kx = K.dot(x)
        
        y = y1
        

        values.append(J(x, y))
        tt.append(time() - begin)
        
    end = time()
    print ("----- Golden-Ratio ADMM with fixed step-----")
    print ("Time execution:", end - begin)
    return [values, x, y,tt]

def pd_Golden_relaxed(J, prox_g, prox_f_conj, K,  x0, y0, sigma, tau, phi, rho, numb_iter=100):
    """
    Relaxed Golden-Ratio PDA for the problem min_x
    max_y [<Kx,y> + g(x) - f*(y)] 
    J denotes some function which we compute in every iteration to
    study perfomance. It may be energy, primal-dual gap, etc.
    """
    begin = time()
    
    x, y, z= x0, y0, x0
    values = [J(x0, y0)]
    tt = [0]
    
    for i in range(numb_iter):    
        z0 = ((phi-1)*x + z)/phi
        x0 = prox_g(z0 - tau * K.T.dot(y), tau)

        y0 = prox_f_conj(y + sigma * K.dot(x0), sigma)
        values.append(J(x0, y0))
        
        z = (1-rho)*z + rho*z0
        x = (1-rho)*x + rho*x0
        y = (1-rho)*y + rho*y0   
        
        tt.append(time() - begin)
        
    end = time()
    print ("----- Relaxed Golden-Ratio PDA -----")
    print ("Time execution:", round(end - begin,2))
    return [values, x, y,tt]


def pd_accelerated_Golden(J, prox_g, prox_f_conj, K,  x0, y1, L, beta,  gamma, numb_iter=100):
    """ 
    accelerated GRPDA for problem min_x max_y [
    <Kx,y> + g(x) - f*(y)].  Corresponds to Alg.4.1 in the paper.  
    beta denotes sigma/tau from a classical primal-dual algorithm.
    """
    begin = time()
    values = [J(x0, y1)]
    tt = [0]
    steps = []
    phi = 1.5
    rho = 1/phi+1/phi**2
    
    sqrt_b = np.sqrt(beta)
    tau = np.sqrt(phi)/(sqrt_b*L)
    
    iterates = [values, x0, x0, y1, tau, beta,K.dot(x0)] + [tt, steps]

    # function T is an operator that makes one iteration of the algorithm:
    # (x1, y1) = T(x,y, history)

    def T(values, z, x_old, y, tau_old, beta_old, Kx_old, tt,steps):
        z = ((phi-1)*x_old + z)/phi
        x = prox_g(z - tau_old * K.T.dot(y), tau_old)
        Kx = K.dot(x)
        
        w = (phi-rho)/(phi/2 + rho*gamma*tau_old)
        beta = (1 + w * gamma * tau_old) * beta_old
        tau = np.minimum(rho*tau_old, phi/(tau_old*beta*L**2))
        y = prox_f_conj(y + tau * beta * Kx, tau * beta)

        #print(rho1)
        
        values.append(J(x, y))
        steps.append(tau*beta)
        tt.append(time() - begin)
        res = [values, z, x, y, tau, beta, Kx, tt,steps]
        return res

    for i in range(numb_iter):
        iterates = T(*iterates)

    end = time()
    print ("----- Accelerated Golden-Ratio PDA-----")
    print ("Time execution:", round(end - begin,2))
    return [iterates[i] for i in [0, 1, -2,-1]]

def pd_accelerated_Golden_t(J, prox_g, prox_f_conj, K,  x0, y1, L,  gamma, numb_iter=100):
    """ 
    accelerated GRPDA for problem min_x max_y [
    <Kx,y> + g(x) - f*(y)].  Corresponds to Alg.4.1 in the paper.  
    beta denotes sigma/tau from a classical primal-dual algorithm.
    """
    begin = time()
    values = [J(x0, y1)]
    tt = [0]
    steps = []
    phi = 1.6
    mu = 0.001
    
    sig = (1-mu)*(phi-1)*gamma/(2*L**2)
    rho = sig
    tau = (1-mu)*phi/(sig*L**2)
    
    iterates = [values, x0, x0, y1, tau, sig, 1] + [tt, steps]

    # function T is an operator that makes one iteration of the algorithm:
    # (x1, y1) = T(x,y, history)

    def T(values, z, x, y, tau, sig,t, tt,steps):
        z = ((phi-1)*x + z)/phi
        x = prox_g(z - tau * K.T.dot(y), tau)
        Kx = K.dot(x)
        y = prox_f_conj(y + sig * Kx, sig)

        #print(rho1)
        
        t = (1+np.sqrt(1+4*t**2))/2
        sig = rho*t
        if sig*L**2 > (1-mu)*gamma:
            tau = (1-mu)*phi/(sig*L**2-(1-mu)*gamma)
        else:
            tau = (1-mu)*phi/(sig*L**2)
        
        values.append(J(x, y))
        steps.append(sig)
        tt.append(time() - begin)
        res = [values, z, x, y, tau, sig, t,tt,steps]
        return res

    for i in range(numb_iter):
        iterates = T(*iterates)

    end = time()
    print ("----- Accelerated Golden-Ratio PDA-----")
    print ("Time execution:", round(end - begin,2))
    return [iterates[i] for i in [0, 1, -2,-1]]



def VI_Golden(J, prox_g, prox_f, K,  x0, y0, tau, phi, numb_iter=100):
    """
    Golden-Ratio algorithm for the problem min_x
    max_y [<Kx,y> + g(x) - f*(y)] 
    J denotes some function which we compute in every iteration to
    study perfomance. It may be energy, primal-dual gap, etc.
    """
    begin = time()
    
    x, y= x0, y0
    z_x, z_y = x0, y0
    values = [J(x0, y0)]
    tt = [0]
    
    for i in range(numb_iter):
        z_x = x-(1/phi)*(x - z_x)
        z_y = y-(1/phi)*(y - z_y)
        
        x1 = prox_g(z_x - tau * K.T.dot(y), tau)
        y1 = prox_f(z_y + tau * K.dot(x), tau)
 
        x, y= x1, y1
        
        
        values.append(J(x, y))
        tt.append(time() - begin)
        
    end = time()
    print ("----- Golden-Ratio Algorithm for VI-----")
    print ("Time execution:", round(end - begin,2))
    return [values, x, y,tt]
